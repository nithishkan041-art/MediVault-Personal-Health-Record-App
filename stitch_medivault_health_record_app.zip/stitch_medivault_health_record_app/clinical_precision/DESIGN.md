---
name: Clinical Precision
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#006056'
  on-tertiary: '#ffffff'
  tertiary-container: '#007b6e'
  on-tertiary-container: '#b1fff1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#71f8e4'
  tertiary-fixed-dim: '#4fdbc8'
  on-tertiary-fixed: '#00201c'
  on-tertiary-fixed-variant: '#005048'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-desktop: 48px
  margin-mobile: 20px
  card-gap: 24px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system is built on the principles of **Clinical Minimalism**. It prioritizes clarity, calm, and professional authority to manage sensitive health data. The aesthetic is inspired by high-end medical instrumentation and modern health-tech platforms, blending the systematic precision of a laboratory with the approachability of a premium consumer app.

The style utilizes a **Modern-Corporate** framework with elements of **Glassmorphism** for secondary overlays. It emphasizes generous whitespace to reduce cognitive load, ensuring that critical health metrics are never obscured by decorative elements. The emotional response is one of safety, reliability, and modern efficiency.

## Colors

The palette is rooted in "Trust Blue" and "Vitality Green." 

- **Primary (Royal Blue):** Used for primary actions, navigation states, and branding. It signals medical authority.
- **Secondary (Emerald Green):** Used for positive health indicators, success states, and "active" status tracking.
- **Accent (Teal):** Reserved for secondary data visualizations and specialized health categories.
- **Background & Surfaces:** A cool-toned slate white (`#F8FAFC`) serves as the canvas, while pure white (`#FFFFFF`) is reserved for interactive cards to create a clear layer of information architecture.

## Typography

This design system uses **Inter** for its neutral, highly legible character, which is essential for reading complex medical data. 

- **Headings:** Bold weights (700) are used for main headers to provide a strong anchor for the eye.
- **Subtitles:** Medium weights (500-600) distinguish subsections without competing with primary headers.
- **Body:** Standard weight (400) with generous line heights (1.5x) ensures long-form medical reports remain readable.
- **Data Labels:** Small, uppercase labels with slightly increased letter spacing are used for metadata and chart axes.

## Layout & Spacing

The layout utilizes a **Fluid-Fixed Hybrid** model. Content is organized into a 12-column grid on desktop with a max-width of 1280px, while remaining fluid on smaller viewports.

- **The Card Grid:** Primary information is housed in cards. Cards should span 4 columns for metrics, 6 columns for charts, and 12 columns for detailed tables.
- **Rhythm:** A base-8 scale is used, but specifically emphasizes `24px` (3 units) for gutters and card gaps to maintain an "airy" and clinical feel.
- **Mobile Adaptation:** On mobile, margins reduce to `20px` and all card columns collapse to a single-column stack.

## Elevation & Depth

This design system uses **Ambient Tonal Elevation**. Depth is communicated through light, natural shadows rather than heavy borders.

- **Level 0 (Background):** `#F8FAFC` - The base canvas.
- **Level 1 (Cards):** `#FFFFFF` - Elevated with a very soft, diffused shadow: `0px 4px 20px rgba(0, 0, 0, 0.05)`.
- **Level 2 (Hover/Active):** When a card or element is interacted with, the shadow deepens to `0px 10px 30px rgba(0, 0, 0, 0.08)` and scales slightly (1.02x).
- **Overlays:** Modals and dropdowns use a background blur (12px) to maintain context of the underlying health data while focusing the user's attention.

## Shapes

The shape language is defined by **Soft Geometricism**. 

- **Primary Radius:** Interactive cards and main containers use a signature `18px` (1.125rem) radius to feel modern and friendly.
- **Secondary Radius:** Buttons and input fields use a `12px` (0.75rem) radius.
- **Small Radius:** Tags and badges use a `6px` radius or full pill-shape depending on the context of the data density.

## Components

### Buttons
- **Primary:** Solid `#2563EB` with white text. High-radius (12px) with a subtle inner glow.
- **Secondary:** Light tint of the primary color (`#EFF6FF`) with blue text. No border.
- **Ghost:** No background, blue text, used for tertiary actions.

### Input Fields
- **Default:** White background with a 1px border (`#E2E8F0`). On focus, the border transitions to Primary Blue with a 3px soft outer glow.
- **Labels:** Always positioned above the field in `label-md` style.

### Cards
- **Stat Cards:** Feature a large `headline-md` value, a `label-sm` title, and a small sparkline trend in the background using the Secondary or Primary color.
- **Content Cards:** Contain 24px internal padding.

### Status Indicators
- **Positive:** Emerald Green chips with 10% opacity backgrounds.
- **Warning:** Amber chips with 10% opacity backgrounds.
- **Critical:** Rose chips with 10% opacity backgrounds.

### Icons
- Use **Line Icons** with a 2px stroke width. Icons should be encased in a soft-rounded square container with a background color matching the icon's category (e.g., heart rate in a light red tint).